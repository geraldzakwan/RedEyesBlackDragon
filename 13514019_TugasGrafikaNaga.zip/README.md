# RedEyesBlackDragon

This is a python program to create a drawing of dragon in which using OpenGL as drawer. We draw the dragon into parts due to fill ability that only can be used into polygon. Those polygons (each part of the body) stored in txt file contains the points connecting the whole form. So the main steps are: read txt file, stored the point into array, draw points from to form polygon, set color for each polygon, done. 
